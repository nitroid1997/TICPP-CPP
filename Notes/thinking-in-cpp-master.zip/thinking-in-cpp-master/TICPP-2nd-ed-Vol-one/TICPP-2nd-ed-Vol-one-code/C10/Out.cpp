//: C10:Out.cpp {O}
// From Thinking in C++, 2nd Edition
// Available at http://www.BruceEckel.com
// (c) Bruce Eckel 2000
// Copyright notice in Copyright.txt
// First file
#include <fstream>
std::ofstream out("out.txt"); ///:~
