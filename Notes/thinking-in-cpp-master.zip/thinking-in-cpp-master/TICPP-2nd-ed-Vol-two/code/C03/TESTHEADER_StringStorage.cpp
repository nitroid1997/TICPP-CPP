//: .\C03:TESTHEADER_StringStorage.cpp
//: C03:StringStorage.h
// From "Thinking in C++, Volume 2", by Bruce Eckel & Chuck Allison.
// (c) 1995-2004 MindView, Inc. All Rights Reserved.
// See source code use permissions stated in the file 'License.txt',
// distributed with the code package available at www.MindView.net.
// This may copy the first to the second or
// use reference counting to simulate a copy:
// Either way, this statement must ONLY modify s1:
// 62345
// 12345
// STRINGSTORAGE_H ///:~
#include"StringStorage.h"
int main() {}
