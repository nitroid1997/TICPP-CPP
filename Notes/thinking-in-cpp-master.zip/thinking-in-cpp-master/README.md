# book code and Some exercise solutions for Bruce Eckel's "Thinking in C++, 2nd Edition".
